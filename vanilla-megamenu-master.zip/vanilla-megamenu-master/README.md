# Responsive Mega Menu

Create a Responsive Navbar Megamenu with HTML5, SCSS, and Vanilla JavaScript.
